using System;
using System.Diagnostics;
using System.Net;
using System.Threading.Tasks;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using AutomationTests.Helpers;
using AutomationTests.ReportManager;

namespace AutomationTests
{
    public class BaseTest 
    {
        public TestContext TestContext { get; set; }
        public HttpStatusCode statusCode;

        [TestInitialize]
        public void SetUpTest()
        {
            Reporter.CreateTest(TestContext.TestName);
        }

        [TestCleanup]
        public void TearDownTest()
        {
            var testStatus = TestContext.CurrentTestOutcome;
            Status status;

            switch (testStatus)
            {
                case UnitTestOutcome.Failed:
                    status = Status.Fail;
                    Reporter.TestStatus(status.ToString());
                    Reporter.LogToReport(Status.Fail, "<b style=\"color: Red; \">Failed</b>");
                    Reporter.LogToReport(Status.Info, "<b>Response URL: </b> <br />" + RestHelper.response.ResponseUri.AbsoluteUri);
                    Reporter.LogToReport(Status.Info, "<b>Response Status Code: </b> <br />" + (int)RestHelper.response.StatusCode);
                    Reporter.LogToReport(Status.Info, "<b>Response: </b> <br />" + RestHelper.response.Content);
                    break;
                case UnitTestOutcome.Passed:
                    status = Status.Pass;
                    Reporter.LogToReport(Status.Pass, "<b style=\"color: MediumSeaGreen; \">Passed</b>");
                    Reporter.LogToReport(Status.Info, "<b>Response URL: </b> <br />" + RestHelper.response.ResponseUri.AbsoluteUri);
                    Reporter.LogToReport(Status.Info, "<b>Response Status Code: </b> <br />" + (int)RestHelper.response.StatusCode);
                    Reporter.LogToReport(Status.Info, "<b>Response: </b> <br />" + RestHelper.response.Content);
                    break;
            }

            //Reporter.GetExtent().Flush();
        }
    }
}