﻿using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationTests.Helpers
{
    public class RestHelper
    {
        public RestClient client;
        //private RestRequest request;

        public static RestResponse response;
        public static RestRequest request;
        public static String requestUrl;

        public RestClient SetUrl(string baseUrl, string endpoint)
        {
            var url = Path.Combine(baseUrl, endpoint);
            requestUrl = url;
            client = new RestClient(url);

            return client;
        }
        public RestRequest CreateGetRequest()
        {
            request = new RestRequest
            {
                Method = Method.Get
            };
            request.AddHeader("Accept", "application/json");
            request.Authenticator = new HttpBasicAuthenticator("UserName", "Password");
            return request;
        }
        public RestRequest CreatePostRequest<T>(T payload) where T : class
        {
            var request = new RestRequest
            {
                Method = Method.Post
            };
            request.AddHeader("Accept", "application/json");
            request.Authenticator = new HttpBasicAuthenticator("UserName", "Password");
            request.AddBody(payload);
            request.RequestFormat = DataFormat.Json;
            return request;
        }
        public RestRequest CreatePutRequest<T>(T payload) where T : class
        {
            request = new RestRequest
            {
                Method = Method.Put
            };
            request.AddHeader("Accept", "application/json");
            request.Authenticator = new HttpBasicAuthenticator("UserName", "Password");
            request.AddBody(payload);
            request.RequestFormat = DataFormat.Json;
            return request;
        }
        public RestRequest CreateDeleteRequest()
        {
            request = new RestRequest
            {
                Method = Method.Delete
            };
            request.AddHeader("Accept", "application/json");
            request.Authenticator = new HttpBasicAuthenticator("UserName", "Password");
            return request;
        }
        public async Task<RestResponse> GetResponseAsync(RestClient restClient, RestRequest restRequest)
        {
            response = await restClient.ExecuteAsync(restRequest);
            return response;
        }
    }
}
