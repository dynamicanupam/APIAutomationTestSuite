﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationTests
{
    internal class Constants
    {
        public static String REPORT_TITLE = "API Automation Test Results";
        public static String REPORT_NAME = "Results.html";
        public static String BASE_URL = "<API_BASE_URL>";
    }
}
