﻿using AventStack.ExtentReports.Reporter.Config;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Model;

namespace AutomationTests.ReportManager
{
    public static class Reporter
    {
        private static ExtentReports extentReports;
        private static ExtentSparkReporter htmlReporter;
        private static ExtentTest extentTest;

        public static ExtentReports GetExtent()
        {
            var dir = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            string reportPath = Path.Combine(dir, "HtmlReport", Constants.REPORT_NAME);
            Console.WriteLine("Report full path : ", reportPath);
            htmlReporter = new ExtentSparkReporter(reportPath);
            htmlReporter.Config.Theme = Theme.Standard;
            htmlReporter.Config.DocumentTitle = Constants.REPORT_TITLE;
            htmlReporter.Config.ReportName = Constants.REPORT_TITLE;

            extentReports = new ExtentReports();
            extentReports.AttachReporter(htmlReporter);

            return extentReports;
        }
        public static void LogToReport(Status status, string message)
        {
            extentTest.Log(status, message);
        }

        public static void CreateTest(string testName)
        {
            extentTest = extentReports.CreateTest(testName);
        }
        public static void FlusReport()
        {
            extentReports.Flush();
        }
        public static void TestStatus(string status)
        {
            if (status.Equals("Pass"))
            {
                extentTest.Pass("Test case passed");
            }
            else
            {
                extentTest.Fail("Test case failed");
            }
        }
    }
}
