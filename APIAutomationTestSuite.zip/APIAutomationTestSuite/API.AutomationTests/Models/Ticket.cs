﻿namespace AutomationTests.Models;
public class Ticket
{
    public string empcode { get; set; }
    public string complainttype { get; set; }
    public string call_reported { get; set; }
    public string contactno { get; set; }
    public string email { get; set; }
    public string ipaddress { get; set; }

}
