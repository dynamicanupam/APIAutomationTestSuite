﻿namespace AutomationTests.Models;
public class Settlement
{
    public string empcode { get; set; }
    public string Resigndate { get; set; }
    public string Relieveddate { get; set; }
    public string Remarks { get; set; }
    public string Initiatedbyusercode { get; set; }
    public string InitiateDate { get; set; }
}
