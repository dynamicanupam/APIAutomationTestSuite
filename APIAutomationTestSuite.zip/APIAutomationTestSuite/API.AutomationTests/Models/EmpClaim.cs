﻿namespace AutomationTests.Models;
public class EmpClaim
{
    public string empcode { get; set; }
    public string year { get; set; }
    public string month { get; set; }
    public string mobileno { get; set; }
    public string createddate { get; set; }
    public string claimed_kms { get; set; }
    public string claimed_amount { get; set; }
    public string approvalstatus { get; set; }
    public string remarks { get; set; }
}