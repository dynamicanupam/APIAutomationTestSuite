using AventStack.ExtentReports;
using AutomationTests.Helpers;
using AutomationTests.Models;
using AutomationTests.ReportManager;
using System.Net;
using System.Text;

namespace AutomationTests
{
    [TestClass]
    public class APIsTest : BaseTest
    {
        [ClassInitialize]
        public static void Setup(TestContext testcontext)
        {
            Reporter.GetExtent();
        }

        [ClassCleanup]
        public static void CleanUp()
        {
            Reporter.FlusReport();
        }

        [TestMethod("Conveyance Claim")]
        public async Task CreateNewConveyanceClaimTest()
        {
            var payload = HandleContent.ParseJson<EmpClaim>("PostClaims.json");

            var helper = new RestHelper();

            var client = helper.SetUrl(Constants.BASE_URL, "api/Employee/PostClaims");
            var request = helper.CreatePostRequest<EmpClaim>(payload);
            var response = await helper.GetResponseAsync(client, request);

            statusCode = response.StatusCode;
            var code = (int)statusCode;
            Assert.AreEqual(201, code);
        }

        [TestMethod("Final Settlement")]
        public async Task CreateFinalSettlementTest()
        {
            var payload = HandleContent.ParseJson<Settlement>("FinalSettlement.json");

            var helper = new RestHelper();

            var client = helper.SetUrl(Constants.BASE_URL, "api/Employee/FinalSettlement");
            var request = helper.CreatePostRequest<Settlement>(payload);
            var response = await helper.GetResponseAsync(client, request);

            statusCode = response.StatusCode;
            var code = (int)statusCode;
            Assert.AreEqual(201, code);
        }

        [TestMethod("Employee Asset")]
        public async Task GetEmployeeAssetTest()
        {
            var helper = new RestHelper();

            var client = helper.SetUrl(Constants.BASE_URL, "api/employee/asset?empcode=9558");
            var request = helper.CreateGetRequest();
            var response = await helper.GetResponseAsync(client, request);

            statusCode = response.StatusCode;
            var code = (int)statusCode;
            Assert.AreEqual(200, code);
        }

        [TestMethod("Employee Attendance")]
        public async Task GetEmployeeAttendanceTest()
        {
            var helper = new RestHelper();

            var client = helper.SetUrl(Constants.BASE_URL, "api/Employee/Attendance?email=test@test.com&fromDate=2023-08-01&toDate=2023-09-08");
            var request = helper.CreateGetRequest();
            var response = await helper.GetResponseAsync(client, request);

            statusCode = response.StatusCode;
            var code = (int)statusCode;
            Assert.AreEqual(200, code);
        }

        [TestMethod("Birthdays")]
        public async Task GetEmployeeBirthdaysTest()
        {
            var helper = new RestHelper();

            var client = helper.SetUrl(Constants.BASE_URL, "api/Employee/Birthdays?date=2023-09-05");
            var request = helper.CreateGetRequest();
            var response = await helper.GetResponseAsync(client, request);

            statusCode = response.StatusCode;
            var code = (int)statusCode;
            Assert.AreEqual(200, code);
        }

        [TestMethod("HelpDesk")]
        public async Task CreateHelpDeskTest()
        {
            var payload = HandleContent.ParseJson<Ticket>("Helpdesk.json");
            payload.call_reported = payload.call_reported + GenerateRandomString(5);
            var helper = new RestHelper();

            var client = helper.SetUrl(Constants.BASE_URL, "api/HelpDesk");
            var request = helper.CreatePostRequest<Ticket>(payload);
            var response = await helper.GetResponseAsync(client, request);

            statusCode = response.StatusCode;
            var code = (int)statusCode;
            Assert.AreEqual(201, code);
        }

        static string GenerateRandomString(int length)
        {
            const string allowedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            Random random = new Random();
            StringBuilder stringBuilder = new StringBuilder(length);

            for (int i = 0; i < length; i++)
            {
                int index = random.Next(allowedChars.Length);
                stringBuilder.Append(allowedChars[index]);
            }

            return stringBuilder.ToString();
        }
    }
}